#ifndef STEGO_H
#define STEGO_H

#include "paillier.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <vector>

using namespace std;



class Stego {
public:
    Stego(string _filename, uint _p, uint _q, uint _n, uint _lam, uint _g, uint _u);//构造函数
    ~Stego();//析构函数
    void preHandler();//预处理函数，把文件处理到合适的域
    void markAndEncode();//先嵌入水印，后加密
    void encodeAndMark();//先加密，后嵌入水印
    void meDecode();//解密函数1
    void emDecode();//解密函数2
    void waterMarking();// 水印信息检测与提取

    double patchworkPlain(string _filename);//明文域上水印计算
    double patchworkEncode(string _filename);//密文域上水印计算
    void meMark();
    void meEncode();
    void emEncode();
    void emMark();


    char* header;// 文件头部信息
    string filename;// 文件名（注意经过预处理后filename会改变）
    Paillier pll;// paillier加解密工具
    uint d;//嵌入水印的差分量
};





#endif