#include "stego.h"

using namespace std;

//测试函数
void test(string filename) {
    srand(time(NULL));
    Stego stego(filename, 13, 19, 247, 36, 248, 199);

    //加解密生成对应的文件
    stego.markAndEncode();
    stego.meDecode();
    stego.encodeAndMark();
    stego.emDecode();


    //按论文表格顺序来
    stego.patchworkPlain(filename + "_preHan");
    stego.patchworkEncode(filename + "_preHan_me_final");
    stego.patchworkPlain(filename + "_preHan_me_decode");
    stego.patchworkEncode(filename + "_preHan_em_final");
    stego.patchworkPlain(filename + "_preHan_em_decode"
    );

    cout << endl;
    cout << endl;
}



int main() {
    test("../results/test-single-8x44100");
    test("../results/POP-single-8x44100");
    test("../results/POP-double-8x44100");
    test("../results/class-single-8x44100");
    test("../results/class-double-8x44100");
    test("../results/audio-single-8x44100");

    system("pause");
    
    return 0;
}