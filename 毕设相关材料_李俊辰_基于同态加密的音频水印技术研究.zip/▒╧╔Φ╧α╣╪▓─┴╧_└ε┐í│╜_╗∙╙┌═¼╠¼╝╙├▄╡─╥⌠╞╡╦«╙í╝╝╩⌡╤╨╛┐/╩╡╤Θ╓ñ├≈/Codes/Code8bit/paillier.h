#ifndef PAILLIER_H
#define PAILLIER_H

#include <utility>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <random>

using namespace std;

typedef unsigned int uint;
typedef unsigned short usht;
typedef long long ll;
typedef unsigned char uch;

class Paillier {
public:
    Paillier(uint _p, uint _q, uint _n, uint _lam, uint _g, uint _u);
    ~Paillier();
    uint encodeRand(uint m);// 随机加密函数
    uint encodeBig(uint m);// 大加密函数
    uint encodeSmall(uint m);// 小加密函数
    uint decode(uint c);// 解密函数
    void enAndDe(uint m); // 加解密函数
    uint encodeBigWithC(uint c, uint d);// 带密文大加密函数
    uint encodeSmallWithC(uint c, uint d);// 带密文小加密函数

    inline uint mulReverseMod(uint x, uint mod);//求乘法逆元
    uint powMod(uint _x, uint n, uint mod);//模幂函数
    inline uint L(uint x);// L函数


    uint p;
    uint q;
    uint n;
    uint lam;
    uint g;
    uint u;
    uint n2;
    uint limit;
    uint phin2;//n2的欧拉函数值


    uint rm = 0;
    
    // uint r = rand() % (n - 1) + 1;
};



#endif