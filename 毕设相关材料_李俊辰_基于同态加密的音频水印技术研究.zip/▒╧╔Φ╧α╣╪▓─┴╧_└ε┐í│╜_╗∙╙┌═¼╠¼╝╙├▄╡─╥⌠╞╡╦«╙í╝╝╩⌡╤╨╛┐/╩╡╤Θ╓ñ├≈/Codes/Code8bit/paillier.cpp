#include "paillier.h"


// 构造函数
Paillier::Paillier(uint _p = 13, uint _q = 19, uint _n = 247, uint _lam = 36, uint _g = 248, uint _u = 199): 
    p(_p), q(_q), n(_n), lam(_lam), g(_g), u(_u)
{
    n2 = n * n;
    limit = n2 / 2;
    phin2 = n * (p - 1) * (q - 1);

    srand(time(NULL));

    // 随机数生成
    // std::default_random_engine se;
    // ge = std::uniform_int_distribution<int>(1, n - 1); // 左闭右闭区间
    // se.seed(time(0));
}

// 析构函数
Paillier::~Paillier() {}

// 加解密函数
void Paillier::enAndDe(uint m) {
    decode(encodeRand(m));

    cout << "加解密成功" << endl;
}


// 解密函数
uint Paillier::decode(uint c) {
    uint m = L(powMod(c, lam, n2)) * u % n;

    // cout << c << "对应的明文为:" << m << endl;

    return m;
}

// 随机加密函数
uint Paillier::encodeRand(uint m) {
    // srand(time(NULL));
    uint r = rand() % (n - 1) + 1;// 使得随机数r > 0 && r < n;
    while (r % p == 0 || r % q == 0) {
        r = rand() % (n - 1) + 1;
    }
    uint c = powMod(g, m, n2) * powMod(r, n, n2) % n2;

    // cout << m << "对应的密文为:" << c << endl;

    return c;
}

// 大加密函数
uint Paillier::encodeBig(uint m) {
    // 使得随机数r > 0 && r < n 且 属于Zn的乘法群
    uint c1 = powMod(g, m, n2);
    uint r = rand() % (n - 1) + 1;
    while (__gcd(r, n) != 1) {
        r = rand() % (n - 1) + 1;
    }
    uint c = c1 * powMod(r, n, n2) % n2;
    while (c < limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(r, n) != 1) {
            r = rand() % (n - 1) + 1;
        }
        c = c1 * powMod(r, n, n2) % n2;
    }

    rm = max(r, rm);

    //cout << m << "对应的密文为:" << c << endl;

    return c;
}


// 小加密函数
uint Paillier::encodeSmall(uint m) {
    // 使得随机数r > 0 && r < n 且 属于Zn的乘法群
    uint c1 = powMod(g, m, n2);
    uint r = rand() % (n - 1) + 1;
    while (__gcd(r, n) != 1) {
        r = rand() % (n - 1) + 1;
    }
    uint c = c1 * powMod(r, n, n2) % n2;
    while (c > limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(r, n) != 1) {
            r = rand() % (n - 1) + 1;
        }
        c = c1 * powMod(r, n, n2) % n2;
    }

    rm = max(r, rm);

    //cout << m << "对应的密文为:" << c << endl;

    return c;
}


// 带密文大加密函数
//密文域上做乘法，相当于明文域上的加法
uint Paillier::encodeBigWithC(uint c, uint d) {
    uint m = d;
    uint left = c * powMod(g, m, n2) % n2;
    uint r = rand() % (n - 1) + 1;
    while (__gcd(r, n) != 1) {
        r = rand() % (n - 1) + 1;
    }
    uint res = left * powMod(r, n, n2) % n2;
    while (res < limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(r, n) != 1) {
            r = rand() % (n - 1) + 1;
        }
        res = left * powMod(r, n, n2) % n2;
    }

    return res;
}

// 带密文小加密函数
// 密文域上做除法，相当于明文域上的减法
uint Paillier::encodeSmallWithC(uint c, uint d) {
    uint m = d;
    uint dc1 = powMod(g, m, n2) % n2;
    uint r = rand() % (n - 1) + 1;
    while (__gcd(r, n) != 1) {
        r = rand() % (n - 1) + 1;
    }
    uint res = c * mulReverseMod(dc1 * powMod(r, n, n2) % n2, n2) % n2;
    while (res > limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(r, n) != 1) {
            r = rand() % (n - 1) + 1;
        }
        res = c * mulReverseMod(dc1 * powMod(r, n, n2) % n2, n2) % n2;
    }

    return res;
}


//求乘法逆元
inline uint Paillier::mulReverseMod(uint x, uint mod) {
    return powMod(x, phin2 - 1, n2);

}


// L函数，设置为内联函数，加快速度
inline uint Paillier::L(uint x) {
    return (x - 1) / n;
}


// 模幂运算
uint Paillier::powMod(uint _x, uint n, uint mod) {
    uint res = 1;
    uint x = _x;
    while (n > 0) {
        if (n & 1) res = res * x % mod;
        x = x * x % mod;
        n = n >> 1;
    }
    return res;
}
