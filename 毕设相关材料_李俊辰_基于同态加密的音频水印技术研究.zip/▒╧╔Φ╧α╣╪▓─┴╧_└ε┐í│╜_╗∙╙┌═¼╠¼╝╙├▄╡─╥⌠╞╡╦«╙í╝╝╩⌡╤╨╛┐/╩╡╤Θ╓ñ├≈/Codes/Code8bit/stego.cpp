#include "stego.h"

// 构造函数
Stego::Stego(string _filename, uint _p, uint _q, uint _n, uint _lam, uint _g, uint _u):
    filename(_filename), pll(_p, _q, _n, _lam, _g, _u) 
{
    header = new char[44];
    d = 1;//嵌入水印的差分量
    preHandler();
}


// 析构函数
Stego::~Stego() {
    delete[] header;
}



// 水印信息检测与提取
void Stego::waterMarking() {
    //封装patchworkPlain和patchworkEncode也行，不封装也行
}


// 明文域上水印计算
double Stego::patchworkPlain(string testfile) {
    // 打开文件
    fstream readstm;
    readstm.open(testfile + ".wav", ios::binary | ios::in);

    //读取头部
    char *buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;

    //数据计算
    //每隔10000个数据点计算一次，然后最终再取平均值
    //最终的平均值是一个加权平均值
    vector<double> gather;
    ll group = 10000;
    long double sum = 0;
    ll cnt = 0;
    uint *left = new uint;
    uint *right = new uint;
    memset(left, 0, sizeof(uint));
    memset(right, 0, sizeof(uint));
    while (readstm.read((char*)left, 1) && readstm.read((char*)right, 1)) {
        if (*left >= *right) sum += (*left - *right);
        else sum -= (*right - *left);
        cnt++;
        if (cnt == group) {
            gather.push_back(sum / group);
            cnt = 0;
            sum = 0;
        }
    }
    // 统计完进行计算
    double dsum = 0;
    for (auto ele : gather) {
        // cout << ele << " ";
        dsum += ele;
    }
    // cout << endl;
    double res;
    if (gather.size() == 0) {
        // 如果一组都不够，直接返回均值
        res = sum / cnt;
        return res;
    }
    else res = dsum / gather.size();
    if (cnt != 0) {
        double last = sum / cnt;
        double load = cnt / group;
        double fenmu = gather.size() + load;
        res = (res * gather.size() + last * load) / fenmu;
    }
    // 释放申请的动态内存
    delete left, right;

    // 输出相关信息
    cout << "Plaintext File [" << testfile + ".wav" << "] Watermark Detection Value: " << res << endl;
    // cout << res << endl;

    //关闭文件
    readstm.close();

    // 返回值
    return res;
}

// 密文域上水印计算
double Stego::patchworkEncode(string testfile) {
    // 打开文件
    fstream readstm;
    readstm.open(testfile + ".wav", ios::binary | ios::in);

    //读取头部
    char *buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;

    //数据计算
    //每隔10000个数据点计算一次，然后最终再取平均值
    //最终的平均值是一个加权平均值
    vector<double> gather;
    ll group = 10000;
    long double sum = 0;
    ll cnt = 0;
    uint *left = new uint;
    uint *right = new uint;
    memset(left, 0, sizeof(uint));
    memset(right, 0, sizeof(uint));
    while (readstm.read((char*)left, 2) && readstm.read((char*)right, 2)) {
        if (*left >= *right) sum += 1;
        // else sum -= 1; 不做sum-的操作
        cnt++;
        if (cnt == group) {
            gather.push_back(sum / group);
            cnt = 0;
            sum = 0;
        }
    }
    // 统计完进行计算
    double dsum = 0;
    for (auto ele : gather) {
        dsum += ele;
    }
    double res;
    if (gather.size() == 0) {
        // 如果一组都不够，直接返回收集过的均值
        res = sum / cnt;
        return res;
    }
    else res = dsum / gather.size();
    if (cnt != 0) {
        double last = sum / cnt;
        double load = cnt / group;
        double fenmu = gather.size() + load;
        res = (res * gather.size() + last * load) / fenmu;
    }
    // 释放申请的动态内存
    delete left, right;

    // 输出相关信息
    cout << "Ciphertext File [" << testfile + ".wav" << "] Watermark Detection Value: " << res << endl;
    // cout << res << endl;

    //关闭文件
    readstm.close();

    // 返回值
    return res;
}



// 对音频文件进行预处理的函数
void Stego::preHandler() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + ".wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_preHan.wav", ios::binary | ios::out);
    //注意，此处更新了filename
    filename = filename + "_preHan";

    // 开始读取和写入头部信息
    readstm.read(header, 44);
    writestm.write(header, 44);

    //预处理数据
    uint *x = new uint;
    memset(x, 0, sizeof(uint));
    while (readstm.read((char*)x, 1)) {
        if (*x == 0) *x = 1;
        else if (*x > pll.n - 2) *x = pll.n - 2;
        writestm.write((char*)x, 1);
    }
    delete x;

    // 关闭文件
    readstm.close();
    writestm.close();
}

//先嵌入水印，后加密
void Stego::markAndEncode() {
    meMark();
    meEncode();
}

//先加密，后嵌入水印
void Stego::encodeAndMark() {
    emEncode();
    emMark();
}

//解密函数1
void Stego::meDecode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_me_final.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_me_decode.wav", ios::binary | ios::out);

    // 对齐文件头
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 解密
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    while (readstm.read((char*)old, 2)) {
        *now = pll.decode(*old);
        writestm.write((char*)now, 1);
    }
    delete old, now;


    // 关闭文件描述符
    readstm.close();
    writestm.close();
}


//解密函数2
void Stego::emDecode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_em_final.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_em_decode.wav", ios::binary | ios::out);

    // 对齐文件头
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 解密
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    while (readstm.read((char*)old, 2)) {
        *now = pll.decode(*old);
        writestm.write((char*)now, 1);
    }
    delete old, now;


    // 关闭文件描述符
    readstm.close();
    writestm.close();
}


void Stego::meMark() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + ".wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_me_mid.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    writestm.write(header, 44);
    delete[] buffer;

    // 处理数据
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    bool flag = false;
    while (readstm.read((char*)old, 1)) {
        if (flag == false) {
            flag = true;
            *now = *old + d;
        } 
        else {
            flag = false;
            *now = *old - d;
        }
        writestm.write((char*)now, 1);
    }
    delete old, now;

    // 关闭文件流
    readstm.close();
    writestm.close();
}



void Stego::meEncode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_me_mid.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_me_final.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 处理数据
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    bool flag = false;
    while (readstm.read((char*)old, 1)) {
        if (flag == false) {
            flag = true;
            *now = pll.encodeBig(*old);
        } 
        else {
            flag = false;
            *now = pll.encodeSmall(*old);
        }
        writestm.write((char*)now, 2);
    }
    delete old, now;

    // 关闭文件流
    readstm.close();
    writestm.close();

}



void Stego::emEncode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + ".wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_em_mid.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 处理数据
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    while (readstm.read((char*)old, 1)) {
        *now = pll.encodeRand(*old);
        writestm.write((char*)now, 2);
    }
    delete old, now;

    // 关闭文件流
    readstm.close();
    writestm.close();
}


void Stego::emMark() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_em_mid.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_em_final.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 处理数据
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    bool flag = false;
    while (readstm.read((char*)old, 2)) {
        if (flag == false) {
            flag = true;
            *now = pll.encodeBigWithC(*old, d);//密文域上做乘法，相当于明文域上的加法
        } 
        else {
            flag = false;
            *now = pll.encodeSmallWithC(*old, d);//密文域上做除法，相当于明文域上的减法
        }
        writestm.write((char*)now, 2);
    }
    delete old, now;

    // 关闭文件流
    readstm.close();
    writestm.close();
}

