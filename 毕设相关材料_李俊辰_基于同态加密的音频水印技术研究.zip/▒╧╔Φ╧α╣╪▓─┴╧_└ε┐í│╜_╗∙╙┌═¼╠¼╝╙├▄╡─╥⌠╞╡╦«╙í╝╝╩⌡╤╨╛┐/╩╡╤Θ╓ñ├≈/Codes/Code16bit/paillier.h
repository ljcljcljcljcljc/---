#ifndef PAILLIER_H
#define PAILLIER_H

#include <utility>
#include <iostream>
#include <cmath>
#include <ctime>
#include <algorithm>

using namespace std;


typedef long long ll;
typedef unsigned long long ull;
typedef unsigned int uint;

class Paillier {
public:
    Paillier(ull _p, ull _q, ull _n, ull _lam, ull _g, ull _u);
    ~Paillier();
    ull encodeRand(ull m);// 随机加密函数
    ull encodeBig(ull m);// 大加密函数
    ull encodeSmall(ull m);// 小加密函数
    ull decode(ull c);// 解密函数
    void enAndDe(ull m); // 加解密函数
    ull encodeBigWithC(ull c, ull d);// 带密文大加密函数
    ull encodeSmallWithC(ull c, ull d);// 带密文小加密函数

    inline ull mulReverseMod(ull x, ull mod);//求乘法逆元
    ull powMod(ull _x, ull n, ull mod);//模幂函数
    inline ull L(ull x);// L函数


    ull p;
    ull q;
    ull n;
    ull lam;
    ull g;
    ull u;
    ull n2;
    ull limit;
    ull phin2;//n2的欧拉函数值

};



#endif