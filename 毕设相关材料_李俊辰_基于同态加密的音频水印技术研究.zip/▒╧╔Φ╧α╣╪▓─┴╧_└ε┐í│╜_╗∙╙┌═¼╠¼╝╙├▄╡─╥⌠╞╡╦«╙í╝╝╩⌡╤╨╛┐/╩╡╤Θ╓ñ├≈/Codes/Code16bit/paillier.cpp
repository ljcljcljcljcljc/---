#include "paillier.h"


// 构造函数
Paillier::Paillier(ull _p = 13, ull _q = 19, ull _n = 247, ull _lam = 36, ull _g = 248, ull _u = 199): 
    p(_p), q(_q), n(_n), lam(_lam), g(_g), u(_u)
{
    n2 = n * n;
    limit = n2 / 2;
    phin2 = n * (p - 1) * (q - 1);

    srand(time(NULL));

}

// 析构函数
Paillier::~Paillier() {}

// 加解密函数
void Paillier::enAndDe(ull m) {
    decode(encodeRand(m));

    cout << "加解密成功" << endl;
}


// 解密函数
ull Paillier::decode(ull c) {
    ull m = L(powMod(c, lam, n2)) * u % n;

    // cout << c << "对应的明文为:" << m << endl;

    return m;
}

// 随机加密函数
ull Paillier::encodeRand(ull m) {
    // srand(time(NULL));
    ull r = rand() % (n - 1) + 1;// 使得随机数r > 0 && r < n;
    while (r % p == 0 || r % q == 0) {
        r = rand() % (n - 1) + 1;
    }
    ull c = powMod(g, m, n2) * powMod(r, n, n2) % n2;

    // cout << m << "对应的密文为:" << c << endl;

    return c;
}

// 大加密函数
ull Paillier::encodeBig(ull m) {
    // 使得随机数r > 0 && r < n 且 属于Zn的乘法群
    ull c1 = powMod(g, m, n2);
    ull r = rand() % (n - 1) + 1;
    while (__gcd(n, r) != 1) {
        r = rand() % (n - 1) + 1;
    }
    ull c = c1 * powMod(r, n, n2) % n2;
    while (c < limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(n, r) != 1) {
            r = rand() % (n - 1) + 1;
        }
        c = c1 * powMod(r, n, n2) % n2;
    }

    //cout << m << "对应的密文为:" << c << endl;

    return c;
}


// 小加密函数
ull Paillier::encodeSmall(ull m) {
    // 使得随机数r > 0 && r < n 且 属于Zn的乘法群
    ull c1 = powMod(g, m, n2);
    ull r = rand() % (n - 1) + 1;
    while (__gcd(n, r) != 1) {
        r = rand() % (n - 1) + 1;
    }
    ull c = c1 * powMod(r, n, n2) % n2;
    while (c > limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(n, r) != 1) {
            r = rand() % (n - 1) + 1;
        }
        c = c1 * powMod(r, n, n2) % n2;
    }

    //cout << m << "对应的密文为:" << c << endl;

    return c;
}


// 带密文大加密函数
//密文域上做乘法，相当于明文域上的加法
ull Paillier::encodeBigWithC(ull c, ull d) {
    ull m = d;
    ull left = c * powMod(g, m, n2) % n2;
    ull r = rand() % (n - 1) + 1;
    while (__gcd(n, r) != 1) {
        r = rand() % (n - 1) + 1;
    }
    ull res = left * powMod(r, n, n2) % n2;
    while (res < limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(n, r) != 1) {
            r = rand() % (n - 1) + 1;
        }
        res = left * powMod(r, n, n2) % n2;
    }

    return res;
}

// 带密文小加密函数
// 密文域上做除法，相当于明文域上的减法
ull Paillier::encodeSmallWithC(ull c, ull d) {
    ull m = d;
    ull dc1 = powMod(g, m, n2) % n2;
    ull r = rand() % (n - 1) + 1;
    while (__gcd(n, r) != 1) {
        r = rand() % (n - 1) + 1;
    }
    ull res = c * mulReverseMod(dc1 * powMod(r, n, n2) % n2, n2) % n2;
    while (res > limit) {
        r = rand() % (n - 1) + 1;
        while (__gcd(n, r) != 1) {
            r = rand() % (n - 1) + 1;
        }
        res = c * mulReverseMod(dc1 * powMod(r, n, n2) % n2, n2) % n2;
    }

    return res;
}


//求乘法逆元
inline ull Paillier::mulReverseMod(ull x, ull mod) {
    return powMod(x, phin2 - 1, n2);

}


// L函数，设置为内联函数，加快速度
inline ull Paillier::L(ull x) {
    return (x - 1) / n;
}


// 模幂运算
ull Paillier::powMod(ull _x, ull n, ull mod) {
    ull res = 1;
    ull x = _x;
    while (n > 0) {
        if (n & 1) res = res * x % mod;
        x = x * x % mod;
        n = n >> 1;
    }
    return res;
}
