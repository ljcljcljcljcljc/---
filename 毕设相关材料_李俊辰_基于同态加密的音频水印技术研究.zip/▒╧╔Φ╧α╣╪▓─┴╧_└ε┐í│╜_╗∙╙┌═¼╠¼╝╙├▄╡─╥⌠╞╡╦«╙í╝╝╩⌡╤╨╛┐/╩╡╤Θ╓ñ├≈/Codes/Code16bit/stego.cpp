#include "stego.h"

//计算域还是在无符号域上，但是读写域换到了有符号域上


// 构造函数
Stego::Stego(string _filename, ull _p, ull _q, ull _n, ull _lam, ull _g, ull _u):
    filename(_filename), pll(_p, _q, _n, _lam, _g, _u) 
{
    header = new char[44];
    d = 1;//嵌入水印的差分量
    preHandler();
}


// 析构函数
Stego::~Stego() {
    delete[] header;
}



// 水印信息检测与提取
void Stego::waterMarking() {
    //封装patchworkPlain和patchworkEncode也行，不封装也行
}


// 明文域上水印计算
double Stego::patchworkPlain(string testfile) {
    // 打开文件
    fstream readstm;
    readstm.open(testfile + ".wav", ios::binary | ios::in);

    //读取头部
    char *buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;

    //数据计算
    //每隔10000个数据点计算一次，然后最终再取平均值
    //最终的平均值是一个加权平均值
    vector<double> gather;
    ll group = 40000;
    double sum = 0;
    ll cnt = 0;
    short *left = new short;
    short *right = new short;
    memset(left, 0, sizeof(short));
    memset(right, 0, sizeof(short));
    while (readstm.read((char*)left, 2) && readstm.read((char*)right, 2)) {
        // if (*left >= *right) sum += (*left - *right);
        // else sum -= (*right - *left);
        sum += (int)*left - (int)*right;
        cnt++;
        if (cnt == group) {
            gather.push_back(sum / (double)group);
            cnt = 0;
            sum = 0;
        }
    }
    // 统计完进行计算
    double dsum = 0;
    for (auto ele : gather) {
        // cout << ele << " ";
        dsum += ele;
    }
    // cout << endl;
    double res;
    if (gather.size() == 0) {
        // 如果一组都不够，直接返回均值
        res = sum / (double)cnt;
        return res;
    }
    else res = dsum / (double)gather.size();
    if (cnt != 0) {
        double last = sum / (double)cnt;
        double load = (double)cnt / (double)group;
        double fenmu = gather.size() + load;
        res = (res * gather.size() + last * load) / fenmu;
    }
    // 释放申请的动态内存
    delete left, right;

    // 输出相关信息
    cout << "Plaintext File [" << testfile + ".wav" << "] Watermark Detection Value: " << res << endl;

    //关闭文件
    readstm.close();

    // 返回值
    return res;
}

// 密文域上水印计算
double Stego::patchworkEncode(string testfile) {
    // 打开文件
    fstream readstm;
    readstm.open(testfile + ".wav", ios::binary | ios::in);

    //读取头部
    char *buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;

    //数据计算
    //每隔10000个数据点计算一次，然后最终再取平均值
    //最终的平均值是一个加权平均值
    vector<double> gather;
    ll group = 10000;
    double sum = 0;
    ll cnt = 0;
    uint *left = new uint;
    uint *right = new uint;
    memset(left, 0, sizeof(uint));
    memset(right, 0, sizeof(uint));
    while (readstm.read((char*)left, 4) && readstm.read((char*)right, 4)) {
        if (*left >= *right) sum += 1;
        // else sum -= 1; 不做sum-的操作
        cnt++;
        if (cnt == group) {
            gather.push_back(sum / group);
            cnt = 0;
            sum = 0;
        }
    }
    // 统计完进行计算
    double dsum = 0;
    for (auto ele : gather) {
        dsum += ele;
    }
    double res;
    if (gather.size() == 0) {
        // 如果一组都不够，直接返回收集过的均值
        res = sum / cnt;
        return res;
    }
    else res = dsum / gather.size();
    if (cnt != 0) {
        double last = sum / cnt;
        double load = cnt / group;
        double fenmu = gather.size() + load;
        res = (res * gather.size() + last * load) / fenmu;
    }
    // 释放申请的动态内存
    delete left, right;

    // 输出相关信息
    cout << "Ciphertext File [" << testfile + ".wav" << "] Watermark Detection Value: " << res << endl;

    //关闭文件
    readstm.close();

    // 返回值
    return res;
}



// 对音频文件进行预处理的函数
void Stego::preHandler() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + ".wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_preHan.wav", ios::binary | ios::out);
    //注意，此处更新了filename
    filename = filename + "_preHan";

    // 开始读取和写入头部信息
    readstm.read(header, 44);
    writestm.write(header, 44);

    //预处理数据
    short *x = new short;
    memset(x, 0, sizeof(short));
    while (readstm.read((char*)x, 2)) {
        //*x的取值范围为-32768~32765
        if (*x < (short)d - 32768) *x = (short)d - 32768;
        else if (*x > (short)((ll)pll.n - (int)d - 1 - 32768)) {
            *x = (short)((ll)pll.n - (int)d - 1 - 32768);
        }
        writestm.write((char*)x, 2);
    }
    delete x;

    // 关闭文件
    readstm.close();
    writestm.close();
}

//先嵌入水印，后加密
void Stego::markAndEncode() {
    meMark();
    meEncode();
}

//先加密，后嵌入水印
void Stego::encodeAndMark() {
    emEncode();
    emMark();
}

//解密函数1
void Stego::meDecode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_me_final.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_me_decode.wav", ios::binary | ios::out);

    // 对齐文件头
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 解密
    uint *old = new uint;
    // uint *now = new uint;
    short *wrt = new short;
    memset(old, 0, sizeof(uint));
    // memset(now, 0, sizeof(uint));
    memset(wrt, 0, sizeof(short));
    while (readstm.read((char*)old, 4)) {
        // *now = pll.decode(*old);
        *wrt = (short)((int)(pll.decode(*old)) - 32768);
        writestm.write((char*)wrt, 2);
    }
    delete old, wrt;
    // delete now;


    // 关闭文件描述符
    readstm.close();
    writestm.close();
}


//解密函数2
void Stego::emDecode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_em_final.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_em_decode.wav", ios::binary | ios::out);

    // 对齐文件头
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 解密
    uint *old = new uint;
    // uint *now = new uint;
    short *wrt = new short;
    memset(old, 0, sizeof(uint));
    // memset(now, 0, sizeof(uint));
    memset(wrt, 0, sizeof(short));
    while (readstm.read((char*)old, 4)) {
        // *now = pll.decode(*old);
        *wrt = (short)((int)(pll.decode(*old)) - 32768);
        writestm.write((char*)wrt, 2);
    }
    delete old, wrt;
    // delete now;


    // 关闭文件描述符
    readstm.close();
    writestm.close();
}


void Stego::meMark() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + ".wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_me_mid.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    writestm.write(header, 44);
    delete[] buffer;

    // 处理数据
    short *old = new short;
    short *now = new short;
    memset(old, 0, sizeof(short));
    memset(now, 0, sizeof(short));
    bool flag = false;
    while (readstm.read((char*)old, 2)) {
        if (flag == false) {
            flag = true;
            *now = *old + (short)d;
        } 
        else {
            flag = false;
            *now = *old - (short)d;
        }
        writestm.write((char*)now, 2);
    }
    delete old, now;

    // 关闭文件流
    readstm.close();
    writestm.close();
}



void Stego::meEncode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_me_mid.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_me_final.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 处理数据
    short *rd = new short;
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    memset(rd, 0, sizeof(short));
    bool flag = false;
    while (readstm.read((char*)rd, 2)) {
        if (flag == false) {
            flag = true;
            *old = *rd + 32768;
            *now = pll.encodeBig(*old);
        } 
        else {
            flag = false;
            *old = *rd + 32768;
            *now = pll.encodeSmall(*old);
        }
        writestm.write((char*)now, 4);
    }
    delete old, now;
    delete rd;

    // 关闭文件流
    readstm.close();
    writestm.close();

}



void Stego::emEncode() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + ".wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_em_mid.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 处理数据
    short *rd = new short;
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    memset(rd, 0, sizeof(short));
    while (readstm.read((char*)rd, 2)) {
        *old = *rd + 32768;
        *now = pll.encodeRand(*old);
        writestm.write((char*)now, 4);
    }
    delete old, now;
    delete rd;

    // 关闭文件流
    readstm.close();
    writestm.close();
}


void Stego::emMark() {
    // 打开读写的两个文件流
    fstream readstm;
    readstm.open(filename + "_em_mid.wav", ios::binary | ios::in);
    fstream writestm;
    writestm.open(filename + "_em_final.wav", ios::binary | ios::out);

    // 处理头部信息，对齐
    char* buffer = new char[44];
    readstm.read(buffer, 44);
    delete[] buffer;
    writestm.write(header, 44);

    // 处理数据
    uint *old = new uint;
    uint *now = new uint;
    memset(old, 0, sizeof(uint));
    memset(now, 0, sizeof(uint));
    bool flag = false;
    while (readstm.read((char*)old, 4)) {
        if (flag == false) {
            flag = true;
            *now = pll.encodeBigWithC(*old, d);//密文域上做乘法，相当于明文域上的加法
        } 
        else {
            flag = false;
            *now = pll.encodeSmallWithC(*old, d);//密文域上做除法，相当于明文域上的减法
        }
        writestm.write((char*)now, 4);
    }
    delete old, now;

    // 关闭文件流
    readstm.close();
    writestm.close();
}

