#include "stego.h"

using namespace std;

void test(string filename){
    srand(time(NULL));
    Stego stego(filename, 233, 281, 65473, 8120, 65474, 30503);

    //加解密生成对应的文件
    stego.markAndEncode();
    stego.meDecode();
    stego.encodeAndMark();
    stego.emDecode();


    //按论文表格顺序来
    stego.patchworkPlain(filename + "_preHan");
    stego.patchworkEncode(filename + "_preHan_me_final");
    stego.patchworkPlain(filename + "_preHan_me_decode");
    stego.patchworkEncode(filename + "_preHan_em_final");
    stego.patchworkPlain(filename + "_preHan_em_decode");

    cout << endl;
    cout << endl;
}


int main() {
    test("../results/test-single-16x44100");
    test("../results/POP-single-16x44100");
    test("../results/POP-double-16x44100");
    test("../results/POP-single-16x32000");
    test("../results/POP-single-16x16000");
    test("../results/class-single-16x44100");
    test("../results/class-double-16x44100");
    test("../results/class-single-16x32000");
    test("../results/class-single-16x16000");
    test("../results/audio-single-16x44100");
    test("../results/audio-single-16x44100");
    test("../results/audio-single-16x16000");

    system("pause");

    return 0;
}