【本级文件目录如下】
“实验证明”
|—Codes
|	|—Code8bit
|	|	|—main.exe
|	|	|—main.cpp
|	|	|—paillier.h
|	|	|—paillier.cpp
|	|	|—stego.h
|	|	|—stego.cpp
|	|—Code16bit
|	|	|—main.exe
|	|	|—main.cpp
|	|	|—paillier.h
|	|	|—paillier.cpp
|	|	|—stego.h
|	|	|—stego.cpp
|	|—results
|	|	|—存放实验中用到的具体音频文件
|—实验结果
|	|—存放具体的实验结果截图					


【代码运行环境】
操作系统：windows11
编译器：gcc 8.2.0
语言：C++17


【一键运行脚本2个】
（1）文件夹“Code8bit”下的“main.exe”
（2）文件夹“Code16bit”下的“main.exe”


【代码文件说明】
main.exe：可执行文件脚本
main.cpp：main函数文件，编写测试逻辑
paillier.h：定义加密函数类paillier
paillier.cpp：实现加密函数类paillier
stego.h：定义隐写类stego
stego.cpp：实现隐写类stego


【音频波形图】
音频波形图是由软件Audacity可视化呈现的。
该软件的下载地址https://www.audacityteam.org/download/









